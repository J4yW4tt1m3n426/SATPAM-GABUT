# SATPAM-GABUT
Bot khusus
